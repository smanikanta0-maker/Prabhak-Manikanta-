1. Open this folder in Android Studio (File > Open) and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Copy app/build/outputs/apk/debug/app-debug.apk to the tablet and install it.
The screens live in app/src/main/assets/index.html.
